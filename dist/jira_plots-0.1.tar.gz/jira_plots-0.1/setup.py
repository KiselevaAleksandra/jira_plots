from setuptools import setup

setup(
    name='jira_plots',
    version='0.1',
    packages=['my_plot'],
    scripts=['jira_plots.py'],
)
